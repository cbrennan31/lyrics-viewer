class SongsController < ApplicationController
  
end
