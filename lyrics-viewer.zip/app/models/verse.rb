class Verse < ApplicationRecord
  belongs_to :song
end
